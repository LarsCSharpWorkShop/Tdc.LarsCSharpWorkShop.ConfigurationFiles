﻿using Microsoft.Extensions.Hosting;
using Tdc.LarsCSharpWorkShop.Api.Configuration;

namespace Tdc.LarsCSharpWorkShop.ConfigurationsAndDI.Api
{
    public class Worker : BackgroundService
    {
        private readonly IHostApplicationLifetime iHostApplicationLifetime;
        private readonly IFolderConfig iFolderConfig;
        public Worker(IHostApplicationLifetime iHostApplicationLifetime, IFolderConfig iFolderConfig)
        {
            this.iFolderConfig = iFolderConfig;
            this.iHostApplicationLifetime = iHostApplicationLifetime;            
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                Console.WriteLine("Hello World!");
            }
            catch
            {
                throw;
            }
            finally
            {
                this.iHostApplicationLifetime.StopApplication();
            }
        }
    }
}
