﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.ConfigurationsAndDI.Api;

IConfiguration configuration = new ConfigurationBuilder()
                        .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                        .AddJsonFile("appsettings.json", false, true)
                        .Build();

HostApplicationBuilder builder = Host.CreateApplicationBuilder(args);
builder.Services.AddHostedService<Worker>();
builder.Services.AddSingleton<IFolderConfig, FolderConfig>(p => FolderConfig.Load(configuration));

IServiceProvider serviceProvider = builder.Services.BuildServiceProvider();

using IHost host = builder.Build();
host.Run();